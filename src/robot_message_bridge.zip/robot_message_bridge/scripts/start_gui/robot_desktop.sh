#!/bin/bash
~/speed/chemist_robot/src/robot_message_bridge/scripts/start_gui/ui_web.py
