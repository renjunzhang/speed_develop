#!/bin/zsh
# ~/speed/chemist_robot/src/robot_message_bridge/scripts/start_gui/ui_server.py

source ~/speed/chemist_robot/devel/setup.zsh
roslaunch robot_message_bridge ui_server.launch
